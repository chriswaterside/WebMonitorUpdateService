<?php

/**
 * Description of session
 *  this class holds information about the current session being run
 *
 * @author chris
 */
class Session {

    private $smtp = null;
    private $adminEmail = null;
    private $email = [];
    private $domain = null;
    private $host, $database, $user, $password;
    private $path, $key;
    private $skipFolders = [];
    private $processExtensions = null;

    public function __construct() {
        date_default_timezone_set('Europe/London');
        Logfile::create("logfiles/logfile");
        if (file_exists('config.php')) {
            require('config.php');
        } else {
            require('config_master.php');
        }
        if (isset($smtp)) {
            $this->smtp = $smtp;
        }
        if (!isset($adminEmail)) {
            $this->adminEmail = "admin@ramblers-webs.org.uk";
        } else {
            $this->adminEmail = $adminEmail;
        }
        $this->checkConfigValue('Domain', $domain);
        $this->checkConfigValue('Email', $email);
        $this->checkConfigValue('Host', $host);
        $this->checkConfigValue('Database', $database);
        $this->checkConfigValue('User', $user);
        $this->checkConfigValue('Path', $path);
        $this->checkConfigValue('Key', $key);
        $this->checkConfigValue('Skip Extensions', $skipExtensions);
        $this->checkConfigValue('Email Interval', $emailinterval);
        $this->domain = $domain;
        $this->host = $host;
        $this->database = $database;
        $this->user = $user;
        $this->password = $password;
        // check $path, ifit  endswith / then remove /
        $this->path = rtrim($path, "/");
        if (!file_exists($this->path)) {
            Logfile::writeError("Path to be scanned does not exist: " . $this->path);
            $this->path = BASE_PATH; // revert to base folder
        }
        if (is_array($email)) {
            foreach ($email as $value) {
                $this->email[] = $value;
            }
        } else {
            $this->email[] = $email;
        }
        $this->key = $key;
        if (isset($skipFolders)) {
            $this->skipFolders = $skipFolders;
        }

        if (isset($joomlaFolders)) {
            foreach ($joomlaFolders as $value) {
                array_push($this->skipFolders, $value . "/tmp/");
                array_push($this->skipFolders, $value . "/logs/");
                array_push($this->skipFolders, $value . "/administrator/logs/");
                array_push($this->skipFolders, $value . "/cache/");
                array_push($this->skipFolders, $value . "/media/plg_jchoptimize/cache/");
                array_push($this->skipFolders, $value . "/plugins/captcha/hydra/imagex/");
                array_push($this->skipFolders, $value . "/administrator/cache/");
                array_push($this->skipFolders, $value . "/administrator/components/com_akeeba/backup/");
            }
        }
        $this->skipExtensions = $skipExtensions;
        $this->emailinterval = $emailinterval;
    }

    public function path() {
        return $this->path;
    }

    public function domain() {
        return $this->domain;
    }

    public function key() {
        return $this->key;
    }

    public function skipFolders() {
        return $this->skipFolders;
    }

    public function processExtensions() {
        return $this->processExtensions;
    }

    public function skipExtensions() {
        return $this->skipExtensions;
    }

    public function emailinterval() {
        return $this->emailinterval;
    }

    public function sendAdminEmail($subject, $body) {
        $mailer = new PHPMailer\PHPMailer\PHPMailer;
        $mailer->addAddress($this->adminEmail, 'Administrator');
        $mailer->Subject = $subject;
        $mailer->msgHTML($body);
        $mailer->isHTML(true);
        if (isset($this->smtp)) {
            $smtp = $this->smtp;
            $mailer->isSMTP();
            $mailer->Host = $smtp->Host;
            $mailer->SMTPAuth = $smtp->SMTPAuth;
            $mailer->Username = $smtp->Username;
            $mailer->Password = $smtp->Password;
            $mailer->Port = $smtp->Port;
            $mailer->setFrom($smtp->FromEmail, $this->domain);
        } else {
            $mailer->setFrom("admin@" . $this->domain, $this->domain);
        }

// only send to administrator for program update and last run not completed errors
        $mailer->addAddress($this->adminEmail, 'Administrator');
        $okay = $mailer->send();
        if ($okay) {
            Logfile::writeWhen('Message has been sent');
        } else {
            Logfile::writeWhen('Message could not be sent.');
            Logfile::writeWhen('Mailer Error: ' . $mailer->ErrorInfo);
        }
        return $okay;
    }

    public function sendStatusEmail($subject, $body) {
        $mailer = new PHPMailer\PHPMailer\PHPMailer;

        $mailer->Subject = $subject;
        $mailer->msgHTML($body);
        $mailer->isHTML(true);
        if (isset($this->smtp)) {
            $smtp = $this->smtp;
            $mailer->isSMTP();
            $mailer->Host = $smtp->Host;
            $mailer->SMTPAuth = $smtp->SMTPAuth;
            $mailer->Username = $smtp->Username;
            $mailer->Password = $smtp->Password;
            $mailer->Port = $smtp->Port;
            $mailer->setFrom($smtp->FromEmail, $this->domain);
        } else {
            $mailer->setFrom("admin@" . $this->domain, $this->domain);
        }
        $mailer->addReplyTo("sitestatus@" . $this->domain, $this->domain);

        foreach ($this->email as $value) {
            $mailer->addAddress($value, 'Web Master');
            Logfile::writeWhen('Email address: ' . $value);
        }

        $okay = $mailer->send();
        if ($okay) {
            Logfile::writeWhen('Message has been sent');
        } else {
            Logfile::writeWhen('Message could not be sent.');
            Logfile::writeWhen('Mailer Error: ' . $mailer->ErrorInfo);
        }
        return $okay;
    }

    public function getDBconfig() {
        $host = $this->host;
        if (!Functions::startsWith($host, "p:")) {
            // make connection persistent
            $host = "p:" . $host;
        }
        return new Dbconfig($host, $this->database, $this->user, $this->password);
    }

    private function checkConfigValue($name, $value) {
        if (!isset($value)) {
            Logfile::writeError($name . ' is not set in config.php file');
            die();
        }
    }

}
